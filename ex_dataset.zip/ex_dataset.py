import matplotlib.pyplot as plt
from path import Path
import os
import torch
import numpy as np

class STM_dataset(Dataset):
    def __init__(self, image_dir, length):
        '''
        Args:
            image_dir (string): Directory with all the images. These are assumed as being .png images. 
                                (filled state only).
            mask_dir (string): Directory with all the masks. These are assumed as being .png images
        '''
        self.length = length
        self.image_dir = image_dir
        self.mask_dir = mask_dir
       
        self.image_files = [torch.tensor(plt.imread(image_dir+f))[0,:,:] for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f))]
        self.image_files = [torch.tensor(plt.imread(mask_dir+f))[0,:,:] for f in os.listdir(image_dir) if os.path.isfile(os.path.join(image_dir, f))]
        
        # NOTE: your transforms here that apply to both the image and the label
        #self.transforms_both = transforms.Compose([
            #
            #RandomRotation_([0, 90, 180, 270])
#            ])
        
        # NOTE: your transforms here that apply to the image only
     #   self.transforms_image_only = transforms.Compose([
            #MedianFilter(3),
        
        #])

    def __len__(self):
        return self.length 

    def __getitem__(self, idx):
        idx = idx % self.__len__() # this just changes the idx to be within the length of the list of images so you can loop over the dataset many times in one epoch

        image, label = self.image_files[idx] # NOTE: check this has the right shape for you!
        # max/min normalization
        image = (image-torch.min(image))/(torch.max(image)-torch.min(image))
        
        # transforms_both returns the original image (in first channel), and the double tip image in zeroth channel
        both = torch.stack((image, label), dim=0)
        image = self.transforms_both(both)


        # separate the image and the label
        label = both[1,:,:]
        image = both[0,:,:]

        # Apply noise transforms, these are applied to the image only, not the label
        image = self.transforms_image_only(image)
        
        return image, label